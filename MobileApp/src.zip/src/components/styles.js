export default {
  container: {
    backgroundColor: "#FFF"
  },
  text: {
    alignSelf: "center",
    marginBottom: 7
  },
  mb: {
    marginBottom: 5

  },
  btnCustom:{
paddingTop:3,
paddingBottom:3,
paddingLeft:3,
paddingRight:3
  },
  wv:{
    padding: 5,
    borderTopColor: '#ddd',
    borderTopWidth:1
  },
  vbHeader:{
    margin:5,
    padding: 5
  },
  vbHeader2:{
  },
  vbHeader2Unread:{
    color: 'red',
  },
  vbHeader3:{
    fontSize: 14
  },
  linkBorder: {
    marginLeft:5,
    marginRight:5,
    marginBottom:7,
    padding:5,
    // borderColor: '#ccc',
    // borderWidth:0.5,
    backgroundColor: '#f1f2f6',
    color: '#1e3799'
  }
};