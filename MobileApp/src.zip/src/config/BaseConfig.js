export const BASE_URL = 'https://voice.quangtri.net.vn/';
//export const BASE_URL = 'http://10.46.100.13:8084/';
export const SNR_CHECK_URL = 'http://voice.quangtri.net.vn:8080/upload/';